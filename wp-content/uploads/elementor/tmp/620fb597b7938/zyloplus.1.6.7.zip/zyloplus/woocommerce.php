<?php get_header(); ?>
<div class="container">
    	<div class="contentwrapper">
			   <?php woocommerce_content(); ?>
		</div><!-- site-aligner -->
</div><!-- content -->     
<?php get_footer(); ?>