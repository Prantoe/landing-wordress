=== Zyloplus ===
Contributors: ClassicTemplate
Tags: blog, custom-colors, custom-logo, full-width-template, featured-images, editor-style, sticky-post, custom-header, custom-background, custom-menu, threaded-comments, theme-options, translation-ready
Requires at least: 5.0
Tested up to: 5.7
Requires PHP: 5.6
Stable tag: 1.6.7
License: GNU General Public License version 2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Zyloplus is a multipurpose WordPress theme which can be used for company, agency, blogger, creative and professional portfolio, business, corporate, informative, travel, design, art or personal website.

== Description ==

Zyloplus is a multipurpose WordPress theme which can be used for company, agency, blogger, creative and professional portfolio, business, agencies, restaurant, sport, medical, startup, ecommerce, corporate, informative, accountant, advertising, consulting, finance, travel, design, art or personal website. This expert template gives you many customization and personalization options. It offers options for Blog, Custom Background, Custom Colors, Custom Header, Custom Logo, Custom Menu, Editor Style, Featured Images, Footer Widgets, Full Width Template, Right Sidebar, Sticky Post, Theme Options, Threaded Comments. The theme is translation ready and supports RTL layout. The design of the theme is beautiful, modern, sophisticated and retina ready. The responsive design also makes it mobile-friendly. It is SEO-optimized so you don’t have to put much efforts for SEO. Also, it is implemented on bootstrap framework.

== Changelog ==

= 1.6.6 =
* Resolved theme errors.
* Changed readme.txt file with standard WP Format.
* Changed url un footer.php file.

= 1.6.7 =
* 

== Resources ==

Zyloplus WordPress Theme, Copyright 2019 ClassicTemplate
Zyloplus is distributed under the terms of the GNU GPL.

Zyloplus Theme is derived from Businessweb Plus, Copyright Grace Themes(gracethemes.com), 2016.
Businessweb Plus WordPress Theme is released under the terms of GNU GPL

Theme is Built using the following resource bundles.

All js that have been used are within folder /js of theme.
jQuery Nivo Slider
Copyright 2012, Dev7studios, under MIT license
http://nivo.dev7studios.com

Montserrat :https://www.google.com/fonts/specimen/Montserrat
License: Distributed under the terms of the Apache License, version 2.0 		
http://www.apache.org/licenses/LICENSE-2.0.html

Font-Awesome
Font Awesome 4.5.0 by @davegandy - http://fontawesome.io - @fontawesome
License - http://fontawesome.io/license (Font: SIL OFL 1.1, CSS: MIT License)